var wms_layers = [];


        var lyr_GoogleSatelliteHybrid_0 = new ol.layer.Tile({
            'title': 'Google Satellite Hybrid',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'
            })
        });
var format_PetaWilayahKecamatanPontianakSelatan_1 = new ol.format.GeoJSON();
var features_PetaWilayahKecamatanPontianakSelatan_1 = format_PetaWilayahKecamatanPontianakSelatan_1.readFeatures(json_PetaWilayahKecamatanPontianakSelatan_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PetaWilayahKecamatanPontianakSelatan_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PetaWilayahKecamatanPontianakSelatan_1.addFeatures(features_PetaWilayahKecamatanPontianakSelatan_1);
var lyr_PetaWilayahKecamatanPontianakSelatan_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_PetaWilayahKecamatanPontianakSelatan_1, 
                style: style_PetaWilayahKecamatanPontianakSelatan_1,
                interactive: true,
    title: 'Peta Wilayah Kecamatan Pontianak Selatan<br />\
    <img src="styles/legend/PetaWilayahKecamatanPontianakSelatan_1_0.png" /> PONTIANAK SELATAN<br />'
        });

lyr_GoogleSatelliteHybrid_0.setVisible(true);lyr_PetaWilayahKecamatanPontianakSelatan_1.setVisible(true);
var layersList = [lyr_GoogleSatelliteHybrid_0,lyr_PetaWilayahKecamatanPontianakSelatan_1];
lyr_PetaWilayahKecamatanPontianakSelatan_1.set('fieldAliases', {'wiadkc': 'wiadkc', });
lyr_PetaWilayahKecamatanPontianakSelatan_1.set('fieldImages', {'wiadkc': 'TextEdit', });
lyr_PetaWilayahKecamatanPontianakSelatan_1.set('fieldLabels', {'wiadkc': 'no label', });
lyr_PetaWilayahKecamatanPontianakSelatan_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});