var wms_layers = [];


        var lyr_GoogleSatelliteHybrid_0 = new ol.layer.Tile({
            'title': 'Google Satellite Hybrid',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'
            })
        });
var format_PetaWilayahDesaPontianakSelatan_1 = new ol.format.GeoJSON();
var features_PetaWilayahDesaPontianakSelatan_1 = format_PetaWilayahDesaPontianakSelatan_1.readFeatures(json_PetaWilayahDesaPontianakSelatan_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PetaWilayahDesaPontianakSelatan_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PetaWilayahDesaPontianakSelatan_1.addFeatures(features_PetaWilayahDesaPontianakSelatan_1);
var lyr_PetaWilayahDesaPontianakSelatan_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_PetaWilayahDesaPontianakSelatan_1, 
                style: style_PetaWilayahDesaPontianakSelatan_1,
                interactive: true,
    title: 'Peta Wilayah Desa Pontianak Selatan<br />\
    <img src="styles/legend/PetaWilayahDesaPontianakSelatan_1_0.png" /> Kelurahan Akcaya<br />\
    <img src="styles/legend/PetaWilayahDesaPontianakSelatan_1_1.png" /> Kelurahan Kota Baru<br />\
    <img src="styles/legend/PetaWilayahDesaPontianakSelatan_1_2.png" /> Kelurahan Melayu Darat<br />\
    <img src="styles/legend/PetaWilayahDesaPontianakSelatan_1_3.png" /> Kelurahan Melayu Laut<br />\
    <img src="styles/legend/PetaWilayahDesaPontianakSelatan_1_4.png" /> Kelurahan Parit Tokaya<br />'
        });

lyr_GoogleSatelliteHybrid_0.setVisible(true);lyr_PetaWilayahDesaPontianakSelatan_1.setVisible(true);
var layersList = [lyr_GoogleSatelliteHybrid_0,lyr_PetaWilayahDesaPontianakSelatan_1];
lyr_PetaWilayahDesaPontianakSelatan_1.set('fieldAliases', {'Nama': 'Nama', 'Luas (Km)': 'Luas (Km)', 'Id': 'Id', });
lyr_PetaWilayahDesaPontianakSelatan_1.set('fieldImages', {'Nama': 'TextEdit', 'Luas (Km)': 'TextEdit', 'Id': 'TextEdit', });
lyr_PetaWilayahDesaPontianakSelatan_1.set('fieldLabels', {'Nama': 'header label', 'Luas (Km)': 'header label', 'Id': 'header label', });
lyr_PetaWilayahDesaPontianakSelatan_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});